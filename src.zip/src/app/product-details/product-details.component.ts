import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-product-details',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css'],
})
export class ProductDetailsComponent {
  public imgArray: string[] = [
    'https://www.boat-lifestyle.com/cdn/shop/files/ACCH3Y28RVDZEZGX_3_1000x.jpg?v=1726838637',
    'https://cdn.shopify.com/s/files/1/0057/8938/4802/products/NirvanaION-FI_White02-a_3000x.png?v=1702007882',
    'https://cdn.shopify.com/s/files/1/0057/8938/4802/products/NirvanaION-FI_White02-b_3000x.png?v=1702007882',
    'https://cdn.shopify.com/s/files/1/0057/8938/4802/products/Crystal_3000x.jpg?v=1702007882'
  ];

  // Initially set the main image
  public imgurl: string = this.imgArray[0];

  // Method to update the main image when hovering over thumbnails
  public updateMainImage(newImage: string): void {
    this.imgurl = newImage;
  }
}
